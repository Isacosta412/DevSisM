---
layout: home

hero:
  name: Maisie Brilliance
  text: documentação do projeto de Desinvolvimento de Sistemas
  tagline: Feito pensando em você e no seu guarda roupas!
  actions:
    - theme: brand
      text: Get Started
      link: /example
    - theme: alt
      text: View on GitHub
      link: https://github.com/vuejs/vitepress
---
