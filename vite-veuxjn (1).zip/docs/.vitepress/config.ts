import { defineConfig } from 'vitepress';

// refer https://vitepress.dev/reference/site-config for details
export default defineConfig({
  lang: 'en-US',
  title: 'Maisie Brilliance',
  description: 'documentação do software do maise brilliance.',

  themeConfig: {
    nav: [
      { text: 'Introdução do projeto', link: '/introduao' },
      { text: 'Descrição do projeto', link: '/descricao' },

      // {
      //   text: 'Dropdown Menu',
      //   items: [
      //     { text: 'Item A', link: '/item-1' },
      //     { text: 'Item B', link: '/item-2' },
      //     { text: 'Item C', link: '/item-3' },
      //   ],
      // },

      // ...
    ],
    search: {
      provider: 'local',
    },
    footer: {
      message: 'Released under the MIT License.',
      copyright: 'Copyright © 2019-present Evan You',
    },

    sidebar: [
      {
        // text: 'Guide',
        items: [
          { text: 'Introduao do projeto', link: '/introduao' },
          { text: 'Descricao do projeto', link: '/descricao' },

          // ...
        ],
      },
    ],
  },
});
